Part 1 and Part 2 can be run by the following command:

    ./maze_exp.py && ./plot.py

# Part 2 Notes
* I found that a lower epsilon value gave more consistent outputs.
* There is generally the agreement that for the first 5 alphas, the average # of steps is the same, then around alpha = 0.5, this increases, and is very different for alpha = 1.0.
* Apologies on not being able to label the x axis properly in part2/Dyna-Q.png for the alpha values tested. Therefore I included the labelled version but note that the x axis scale is different in each of the PNGs but still displays the same data.